# Installing Webfonts
Follow these simple Steps.

## 1.
Put `montserrat/` Folder into a Folder called `fonts/`.

## 2.
Put `montserrat.css` into your `css/` Folder.

## 3. (Optional)
You may adapt the `url('path')` in `montserrat.css` depends on your Website Filesystem.

## 4.
Import `montserrat.css` at the top of you main Stylesheet.

```
@import url('montserrat.css');
```

## 5.
You are now ready to use the following Rules in your CSS to specify each Font Style:
```
font-family: Montserrat-Thin;
font-family: Montserrat-ThinItalic;
font-family: Montserrat-Light;

```

